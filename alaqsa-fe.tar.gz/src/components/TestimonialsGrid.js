import RevealObserver from "./RevealObserver";

export default function TestimonialsGrid({ items = [] }) {
  if (!items.length) return null;

  const stars = (n) => "★".repeat(n) + "☆".repeat(5 - n);

  return (
    <>
      <RevealObserver />
      <section className="band" style={{ background: "var(--bg)" }}>
        <div className="wrap">
          <div className="band-head rv">
            <span className="tag ar">عملاؤنا</span>
            <h2>آراء من جاءوا وعادوا</h2>
          </div>
          <div className="testi-grid">
            {items.map((t) => (
              <div key={t.id} className="testi-card rv">
                <div className="testi-top">
                  {t.photo_url ? (
                    <img src={t.photo_url} alt={t.customer_name} className="testi-avatar" />
                  ) : (
                    <div className="testi-avatar testi-initials">
                      {t.customer_name?.[0]?.toUpperCase()}
                    </div>
                  )}
                  <div>
                    <div className="testi-name">{t.customer_name}</div>
                    <div className="testi-stars">{stars(t.rating)}</div>
                  </div>
                </div>
                <p className="testi-text">«{t.review_text}»</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
